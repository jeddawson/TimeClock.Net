﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TimeClock.Resources
{
    public class Constants
    {
        public static bool  PRODUCTION          = false;
        public static int   DEFAULT_DEPARTMENT  = 1;
        public static int   DEFAULT_PUNCH_TYPE  =  1;
    }
}
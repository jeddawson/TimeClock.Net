namespace TimeClock.Migrations
{
    using System.Data.Entity.Migrations;
    
    public partial class lineVirtualPunch : DbMigration
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
}
